﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LojaVendeTudo
{
    internal enum MarcaEletronico
    {
        APPLE,
        MICROSOFT,
        GOOGLE,
        SAMSUNG,
        LG,
        OUTROS
    }
}
