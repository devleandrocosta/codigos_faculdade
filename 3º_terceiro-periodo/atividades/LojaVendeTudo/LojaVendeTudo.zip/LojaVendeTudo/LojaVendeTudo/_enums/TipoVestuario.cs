﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LojaVendeTudo
{
    internal enum TipoVestuario
    {
        POPULAR = 1,
        LUXO = 2,
        ALTA_COSTURA = 3
    }
}
